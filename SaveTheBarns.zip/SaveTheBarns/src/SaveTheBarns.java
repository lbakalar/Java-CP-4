/*
 * Libby Bakalar
 * This program is to gain experience with simple loops, decision processing, counters and accumulators, file input and validation.
 * It will accumulate averages based off contributions and average them by the counters.
 * Then it will output all totals
 */

import java.text.NumberFormat;
import java.text.DecimalFormat; 
import java.time.LocalDate; 
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.io.*;

public class SaveTheBarns {
	
	//Variables
	static Scanner myScanner; 													//input device
	static NumberFormat nf;
	static DecimalFormat dfDouble; 
	static LocalDate today = LocalDate.now();									//holds current date, without time portion 
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");	//used to format date 
	static PrintWriter pw;		//used to write data to the .prt file
	
	//string Variables
	static String iName;  		//input name
	static String iAddress;		//input address
	static String iCity;		//input city
	static String iState; 		//input state
	static String iZip;			//input zip code 
	static String iParty;		//input party
	static String iGender; 		//input gender 
	static String iCont; 		//input contribution	 
	static String iRecord = ""; 
	static String oErrMsg; //error messages
	
	static String oMRepCont, oMInCont, oMDemCont, oMCont;	//formatted men contribution 
	static String oFRepCont, oFInCont, oFDemCont, oFCont;	//formatted women contribution
	static String oTotalCont, oDemCont, oRepCont, oInCont; 	//formatted total, dem, rep, and independent contributions
	static String oMRepAvg, oMInAvg, oMDemAvg, oMAvg;		//formatted men averages 
	static String oFRepAvg, oFInAvg, oFDemAvg, oFAvg;		//formatted women averages
	static String oTotalAvg, oDemAvg, oRepAvg, oInAvg;		//formatted total, dem, rep, and independent averages
	
	//double variables	
	static double cZip; 	
	static double cCont; 
	static double cMRepCont=0, cMInCont=0, cMDemCont=0, cMCont=0;	//men contribution 
	static double cFRepCont=0.0, cFInCont=0.0, cFDemCont=0.0, cFCont=0.0;	//women contribution
	static double cTotalCont=0.0, cDemCont=0.0, cRepCont=0.0, cInCont=0.0;	//total, dem, rep, and independent contributions
	static double cMRepAvg, cMInAvg, cMDemAvg, cMAvg;		//men averages 
	static double cFRepAvg, cFInAvg, cFDemAvg, cFAvg;		//women averages
	static double cTotalAvg, cDemAvg, cRepAvg, cInAvg; 		//total, dem, rep, and independent averages
	
	//int variables
	static int cMRepCtr=0, cMInCtr=0, cMDemCtr=0, cMCtr=0; 			//men ctrs
	static int cFRepCtr=0, cFInCtr=0, cFDemCtr=0, cFCtr=0; 			//women ctrs 
	static int cTotalCtr=0, cDemCtr=0, cRepCtr=0, cInCtr=0; 		//total, rep, dem, and independent ctrs
	
	//boolean variables
	static boolean eof = false;
	static boolean errorSwitch = true;	
	
	public static void main(String[] args) {
		
		//call init
		init();
		
		while(!eof) {
			validate();
			
			if (errorSwitch = true) {
				//call calcs
				calcs();
				input();
			}
			else {
				error();
				input();
			}
			
		//bracket to end while	
		} 
		
		output();
		
	//bracket to end main	
	}
	
	public static void init() {
		try {
			myScanner = new Scanner(new File("contributors.dat"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		}
		catch(FileNotFoundException e) {
			System.out.println("File Error");
			System.exit(1);			
		}
		
		dfDouble = new DecimalFormat("$#,###,###.00");
		
		//initialize the PrintWriter object
		try {
			pw = new PrintWriter(new File ("error.prt"));
		} 
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		input();
				
	//bracket to end init	
	}
	
	public static void input() {
		if(myScanner.hasNext()) {
			iRecord = myScanner.next();
		}
		else 
			eof = true;
		
	//bracket to end input	
	}
	
	public static void error() {
		
		//print record to error.prt		
		pw.println(iRecord + oErrMsg);
	}
	
	public static void validate() {
		errorSwitch = true; 
		
		iName = iRecord.substring(0,25);
		if (iName.isEmpty()) {
			oErrMsg = "Error, Name required";
			errorSwitch=false;		
		}
		
		iAddress = iRecord.substring(25,50).trim();
		if (iAddress.isEmpty()) {
			oErrMsg = "Error, Address required";
			errorSwitch=false;			
		}
		
		iCity = iRecord.substring(50,65).trim();
		if (iCity.isEmpty()) {
			oErrMsg = "Error, City required";
			errorSwitch=false;			
		}
		
		iState = iRecord.substring(65,67).trim();
		if (iState.isEmpty()) {
			oErrMsg = "Error, State required";
			errorSwitch=false;			
		}		
		
		try {
			iZip = iRecord.substring(67,72).trim();
			cCont = Integer.parseInt(iCont);
			 if (cZip < 00000 || cZip > 99999) {
				 oErrMsg = "Error, Zip Code must be 5 digits.";
				 errorSwitch=false;			
			 }
		//bracket to end try	 
		}
		catch (NumberFormatException e) {
			oErrMsg = "Contribution is not numeric";
			errorSwitch = false; 			
		//bracket to end catch	
		}
		
		
		iParty = iRecord.substring(72,73).trim();
		iParty = iParty.toUpperCase();
		if (iParty.matches("[^R,I,D]")) {
			oErrMsg = "Not a errorSwitch Party. Party must be R, I, or D.";
			errorSwitch = false; 			
		}
		
		iGender = iRecord.substring(73,74).trim();
		iGender = iGender.toUpperCase();
		if (iGender.matches("[^M,F]")) {
			oErrMsg = "Not a errorSwitch Gender. Gender must be M or F.";
			errorSwitch = false;		
		}
	
		try {
			iCont = iRecord.substring(74,78).trim();
			cCont = Integer.parseInt(iCont);
			 if (cCont < 0.01 || cCont > 9999.99) {
				 oErrMsg = "Error, Contribution must be between 0.01 - 9999.99.";
				 errorSwitch=false;			
			 }
		}
		catch (NumberFormatException e) {
			oErrMsg = "Contribution is not numeric";
			errorSwitch = false; 			
		//bracket to end catch	
		}		
		
		errorSwitch = false;
				
	//bracket to end errorSwitchate	
	}
	
	
	public static void calcs() {
		
		cCont = Integer.parseInt(iCont);
		cTotalCtr += 1;		
		
		//switch for party
		switch (iParty) {
			case "R":
				cRepCtr += 1;
				cRepCont += cCont;
				if (iGender.equals("M")) {
					cMRepCtr += 1;
					cMCtr += 1;
					cMCont = cMCont + cCont;
					cMRepCont = cMRepCont + cCont;
				}
				else {
					cFRepCtr += 1;
					cFCtr += 1;
					cFCont = cFCont + cCont;
					cFRepCont = cFRepCont + cCont;
				}
				break;

			case "D":
				cDemCtr += 1;
				cDemCont += cCont;
				if (iGender.equals("M")) {
					cMDemCtr += 1;
					cMCtr += 1;
					cMCont = cMCont + cCont;
					cMDemCont = cMDemCont + cCont;
				}
				else {
					cFDemCtr += 1;
					cFCtr += 1;
					cFCont = cFCont + cCont;
					cFDemCont = cFDemCont + cCont;
				}
				break;

			case "I":
				cInCtr += 1;
				cInCont += cCont;
				if (iGender.equals("M")) {
					cMInCtr += 1;
					cMCtr += 1;
					cMCont = cMCont + cCont;
					cMInCont = cMInCont + cCont;
				}
				else {
					cFInCtr += 1;
					cFCtr += 1;
					cFCont = cFCont + cCont;
					cFInCont = cFInCont + cCont;
				}
				break;				
		}  
		
		cTotalCont = cTotalCont + cCont;
					
		//calculating averages
		
		//calculating Men average and catch if 0
		try {
			cMAvg = cMCont / cMCtr;
		}
		catch (Exception e){
			cMAvg = 0;
		}
		
		//calculating Women average and catch if 0
		try {
			cFAvg = cFCont / cFCtr;
		}
		catch (Exception e){
			cFAvg = 0;
		}
		
		//calculating Democrat average and catch if 0
		try {
			cDemAvg = cDemCont / cDemCtr;
		}
		catch (Exception e){
			cDemAvg = 0;
		} 
		
		//calculating Republican average and catch if 0
		try {
			cRepAvg = cRepCont / cRepCtr;
		}
		catch (Exception e){
			cRepAvg = 0;
		}
		
		//calculating Independent average and catch if 0
		try {
			cInAvg = cInCont / cInCtr;
		}
		catch (Exception e){
			cInAvg = 0;
		}		
		
		//calculating Men Democrat average and catch if 0
		try {
			cMDemAvg = cMDemCont / cMDemCtr;
		}
		catch (Exception e){
			cMDemAvg = 0;
		}
		
		//calculating Female average and catch if 0
		try {
			cFDemAvg = cFDemCont / cFDemCtr;
		}
		catch (Exception e){
			cFDemAvg = 0;
		}
		
		//calculating Men Republican average and catch if 0
		try {
			cMRepAvg = cMRepCont / cMRepCtr;
		}
		catch (Exception e){
			cMRepAvg = 0;
		}
		
		//calculating Female Republican average and catch if 0
		try {
			cFRepAvg = cFRepCont / cFRepCtr;
		}
		catch (Exception e){
			cFRepAvg = 0;
		}
		
		//calculating Male Independent average and catch if 0
		try {
			cMInAvg = cMInCont / cMInCtr;
		}
		catch (Exception e){
			cMInAvg = 0;
		}
		
		//calculating Female Independent average and catch if 0
		try {
			cFInAvg = cFInCont / cFInCtr;
		}
		catch (Exception e){
			cFInAvg = 0;
		}
		
		//calculating Total average and catch if 0
		try {
			cTotalAvg = cTotalCont / cTotalCtr;
		}
		catch (Exception e){
			cTotalAvg = 0;
		}
		
	//bracket to end calcs	
	}
		
	public static void output() {
		
		//formatting contributions		
		oMCont = dfDouble.format(cMCont);		
		oFCont = dfDouble.format(cFCont);		
		oDemCont = dfDouble.format(cDemCont);
		oRepCont = dfDouble.format(cRepCont);
		oInCont = dfDouble.format(cInCont);
		oMDemCont = dfDouble.format(cMDemCont);
		oFDemCont = dfDouble.format(cFDemCont);
		oMRepCont = dfDouble.format(cMRepCont);
		oFRepCont = dfDouble.format(cFRepCont);
		oMInCont = dfDouble.format(cMInCont);
		oFInCont = dfDouble.format(cFInCont);
		oTotalCont =dfDouble.format(cTotalCont);
		
		//formatting averages
		oMAvg = dfDouble.format(cMAvg);
		oFAvg = dfDouble.format(cFAvg);
		oRepAvg = dfDouble.format(cRepAvg);
		oDemAvg = dfDouble.format(cDemAvg);
		oInAvg = dfDouble.format(cInAvg);
		oMRepAvg = dfDouble.format(cMRepAvg);
		oFRepAvg = dfDouble.format(cFRepAvg);
		oMDemAvg = dfDouble.format(cMDemAvg);
		oFDemAvg = dfDouble.format(cFDemAvg);
		oMInAvg = dfDouble.format(cMInAvg);
		oFInAvg = dfDouble.format(cFInAvg);		
		oTotalAvg = dfDouble.format(cTotalAvg);
		
		
		System.out.println(System.out.format("%-21s", today.format(dtf))+ String.format("%-22s", "Company Title Line"));
		
		System.out.println(System.out.format("%-21s", "") + String.format("%-22s", "Report Title Line"));
		
		System.out.println(String.format("%-21s", "Men") + String.format("%-22s", cMCtr) + String.format("%-23s", oMCont)
		+ String.format("%-10s", oMAvg));
		
		System.out.println(String.format("%-21s", "Women") + String.format("%-22s", cFCtr) + String.format("%-23s", oFCont)
		+ String.format("%-10s", oFAvg));
		
		System.out.println(String.format("%-21s", "Democrats") + String.format("%-22s", cDemCtr) + String.format("%-23s", oDemCont)
		+ String.format("%-10s", oDemAvg));
		
		System.out.println(String.format("%-21s", "Republicans") + String.format("%-22s", cRepCtr) + String.format("%-23s", oRepCont)
		+ String.format("%-10s", oRepAvg));
		
		System.out.println(String.format("%-21s", "Independents") + String.format("%-22s", cInCtr) + String.format("%-23s", oInCont)
		+ String.format("%-10s", oInAvg));
		
		System.out.println(String.format("%-21s", "Democrat Men") + String.format("%-22s", cMDemCtr) + String.format("%-23s", oMDemCont)
		+ String.format("%-10s", oMDemAvg));
		
		System.out.println(String.format("%-21s", "Democrat Women") + String.format("%-22s", cFDemCtr) + String.format("%-23s", oFDemCont)
		+ String.format("%-10s", oFDemAvg));
		
		System.out.println(String.format("%-21s", "Republican Men") + String.format("%-22s", cMRepCtr) + String.format("%-23s", oMRepCont)
		+ String.format("%-10s", oMRepAvg));
		
		System.out.println(String.format("%-21s", "Republican Women") + String.format("%-22s", cFRepCtr) + String.format("%-23s", oFRepCont)
		+ String.format("%-10s", oFRepAvg));
		
		System.out.println(String.format("%-21s", "Independent Men") + String.format("%-22s", cMInCtr) + String.format("%-23s", oMInCont)
		+ String.format("%-10s", oMInAvg));
		
		System.out.println(String.format("%-21s", "Independent Women") + String.format("%-22s", cFInCtr) + String.format("%-23s", oFInCont)
		+ String.format("%-10s", oFInAvg));
		
		System.out.println(String.format("%-21s", "Overall Totals") + String.format("%-22s", cTotalCtr) + String.format("%-23s", oTotalCont)
		+ String.format("%-10s", oTotalAvg));
		
	//bracket to end output	
	}				
	
//bracket to end program	
}
